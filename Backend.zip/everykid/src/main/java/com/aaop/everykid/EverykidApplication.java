package com.aaop.everykid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverykidApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverykidApplication.class, args);
	}

}
