package com.aaop.everykid.constant;

public enum Role {
    PARENTS, TEACHERS
}
