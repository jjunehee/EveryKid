package com.aaop.everykid.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisterCFormDto {
    public Long pKID;
   // private String cIMG;
    private String CNAME;
    private String CAGE;
}
