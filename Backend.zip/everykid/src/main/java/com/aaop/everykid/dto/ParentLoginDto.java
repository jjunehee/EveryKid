package com.aaop.everykid.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
public class ParentLoginDto {

    private String pID;

    private String pPWD;
}
