package com.aaop.everykid.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Date;

public class NoticeKey implements Serializable {
    Long KKID;
    Date writeDate;
}
