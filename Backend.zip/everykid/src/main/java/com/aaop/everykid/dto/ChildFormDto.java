package com.aaop.everykid.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChildFormDto {
    private String C_NAME;
    private String C_AGE;
/*    private Boolean C_STATUS;
    private String C_IMG;*/

}
