package com.aaop.everykid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverykidApplicationTests {

	@Test
	void contextLoads() {
	}

}
